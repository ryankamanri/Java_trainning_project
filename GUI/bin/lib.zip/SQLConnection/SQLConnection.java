package SQLConnection;

import Model.Account;
import Model.CreditAccount;
import Model.LoansAccount;
import Model.SavingAccount;

import java.sql.*;


public class SQLConnection
{
    //连接数据库的所有属性
    private static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";//jdbc ->sql server 驱动器
    private static String dbURL = "jdbc:sqlserver://localhost:1433;DatabaseName=Account";
    private static String userName = "user";
    private static String userPwd = "123456";
    static Connection dbConn = null;

    public void GetConnection()
    {
        try
        {
            Class.forName(driverName);
            dbConn = DriverManager.getConnection(dbURL, userName, userPwd);
            System.out.println("连接数据库成功");
        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.out.print("连接失败");
        }
    }

    public void InsertAccount(String type, Account a) throws SQLException
    {
        try
        {
            PreparedStatement pstmt = dbConn.prepareStatement("INSERT INTO dbo.Account values(?,?,?)");
            pstmt.setString(1, type);
            pstmt.setString(2, a.toSQLServerString());
            pstmt.setString(3,String.valueOf(a.getId()));
            pstmt.executeUpdate();
            System.out.println("成功写入" + a.toString());
            pstmt.close();
            dbConn.close();
        }catch (Exception e)
        {
            System.out.println("写入失败");
        }

    }

    public void DeleteAccount(String type, Account a) throws SQLException
    {
        try
        {
            PreparedStatement pstmt = dbConn.prepareStatement("DELETE FROM dbo.Account WHERE class=?");
            pstmt.setString(1, a.toSQLServerString());
            pstmt.executeUpdate();
            System.out.println("删除成功" + a.toString());
            pstmt.close();
            dbConn.close();
        }catch(Exception e)
        {
            System.out.println("删除失败");
        }

    }

    public void UpdateAccount(String type,Account a) throws SQLException
    {
        try
        {
            PreparedStatement pstmt = dbConn.prepareStatement("UPDATE dbo.Account SET class=? WHERE id=?");
            pstmt.setString(1,a.toSQLServerString());
            pstmt.setString(2,String.valueOf(a.getId()));
            pstmt.executeUpdate();
            System.out.println("修改成功");
            pstmt.close();
            dbConn.close();
        }catch(Exception e)
        {
            System.out.println("修改失败");
        }
    }

    public Account SelectAccount(long id) throws SQLException
    {
        String queryAnswer = null,queryType = null;
        Account a = null;
        try
        {
            PreparedStatement pstmt = dbConn.prepareStatement("SELECT type,class FROM dbo.Account WHERE id=?");
            pstmt.setString(1, String.valueOf(id));
            ResultSet rs = pstmt.executeQuery();
            while(rs.next())
            {
                queryType = rs.getString(1);
                queryAnswer = rs.getString(2);
            }

            if(queryAnswer == null)
            {
                System.out.println("该账户不存在");
                return null;
            }
            System.out.println("查询成功");
        }catch(Exception e)
        {
            System.out.println("查询失败");
            return null;
        }
        String[] splitQueryAnswer = queryAnswer.split(",");
        switch (queryType)
        {
            case "CreditAccount": a = new CreditAccount(); break;
            case "SavingAccount": a = new SavingAccount();break;
            case "LoansAccount" : a = new LoansAccount(
                    Long.parseLong(splitQueryAnswer[0]),
                    splitQueryAnswer[1],
                    splitQueryAnswer[2],
                    splitQueryAnswer[3],
                    splitQueryAnswer[4],
                    Double.parseDouble(splitQueryAnswer[5]),
                    new LoansAccount.Mortgage(Integer.parseInt(splitQueryAnswer[6]),
                            Integer.parseInt(splitQueryAnswer[7]),
                            Integer.parseInt(splitQueryAnswer[8]),
                            Integer.parseInt(splitQueryAnswer[9])),
                            Integer.parseInt(splitQueryAnswer[10])
                    );
            break;
        }
        return a;
    }
}
